package com.example.AmqDemo.Controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.AmqDemo.Sender;

import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class HelloController {
	
	@Autowired
	Sender sender;
	
	@RequestMapping("/AppDemo")
    public String index() throws JMSException {
		for(int i=0; i<100; i++) {
		sender.sendToQueue("inbound.queue", "Hello Queue ");
		sender.sendToTopic("inbound.topic", "Hello Topic");
		sender.sendToDurableTopic("inbound.durable.topic", "Hello Topic");
		}
        return "Successfully posted messages";
    }

}
