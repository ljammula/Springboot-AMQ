package com.example.AmqDemo;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Listener2 {

	@JmsListener(destination = "inbound.topic", containerFactory = "myTopicFactory")
	public void receiveMessage(final Message jsonMessage) throws JMSException {
		System.out.println("Received message in Listener-2" + jsonMessage);
	}

}