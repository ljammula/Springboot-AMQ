package com.example.AmqDemo;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Listener {

	@JmsListener(destination = "inbound.durable.topic", id="commercial", subscription = "dummy_subscription", containerFactory = "myFactory")
	public void receiveMessageFromDurableTopic(final Message jsonMessage) throws JMSException {
		System.out.println("Received message " + jsonMessage);
	}

}