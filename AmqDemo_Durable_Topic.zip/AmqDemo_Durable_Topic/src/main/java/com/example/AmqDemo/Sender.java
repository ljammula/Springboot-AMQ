package com.example.AmqDemo;

import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class Sender {
	
	@Autowired
	@Qualifier("JmsDurableTemplateTopic")
	JmsTemplate jmsTemplate3;
	
	public void sendToDurableTopic(String topic, String message) throws JMSException {
		// Send a message
        System.out.println("Sending a message = " + message);
        jmsTemplate3.convertAndSend(topic, message);
	}

}
